import torch
from torch import nn, optim
import torch.nn.functional as F
from torch.nn import LSTMCell
import numpy as np

class ConcreteDropout(nn.Module):
    def __init__(self, weight_regularizer=1e-6,
                 dropout_regularizer=1e-5, init_min=0.1, init_max=0.1):
        super(ConcreteDropout, self).__init__()

        
        self.weight_regularizer = weight_regularizer
        self.dropout_regularizer = dropout_regularizer
        
        init_min = np.log(init_min) - np.log(1. - init_min)
        init_max = np.log(init_max) - np.log(1. - init_max)
        
        self.p_logit = nn.Parameter(torch.empty(1).uniform_(init_min, init_max))
        #print('self.p_logit: ', self.p_logit)
        
    def forward(self, x, layer):
        p = torch.sigmoid(self.p_logit)
        #print('p: ', p)
        
        out = layer(self._concrete_dropout(x, p))
        #print('layer.parameters(): ', layer.parameters())
        sum_of_square = 0
        for param in layer.parameters():
            sum_of_square += torch.sum(torch.pow(param, 2))
        
        weights_regularizer = self.weight_regularizer * sum_of_square / (1 - p)
        
        dropout_regularizer = p * torch.log(p)
        dropout_regularizer += (1. - p) * torch.log(1. - p)
        
        input_dimensionality = x[0].numel() # Number of elements of first item in batch
        dropout_regularizer *= self.dropout_regularizer * input_dimensionality
        
        regularization = weights_regularizer + dropout_regularizer
        return out, regularization
        
    def _concrete_dropout(self, x, p):
        eps = 1e-7
        temp = 0.1

        unif_noise = torch.rand_like(x)

        drop_prob = (torch.log(p + eps)
                    - torch.log(1 - p + eps)
                    + torch.log(unif_noise + eps)
                    - torch.log(1 - unif_noise + eps))
        
        drop_prob = torch.sigmoid(drop_prob / temp)
        random_tensor = 1 - drop_prob
        retain_prob = 1 - p
        
        x  = torch.mul(x, random_tensor)
        x /= retain_prob
        
        return x
        
        
class LSTM_With_CDO(nn.Module):
    # initial function
    def __init__(self, hidden_size, past_unit, future_unit):
        super(LSTM_With_CDO, self). __init__()
        self.lstm = LSTMCell(1, hidden_size)
        self.linear = nn.Linear(hidden_size, 1)
        self.sigma = nn.Linear(hidden_size, 1)
        self.hidden_size = hidden_size
        # self.linear2 = nn.Linear(HIDDEN_SIZE, HIDDEN_SIZE)
        self.conc_drop = ConcreteDropout()
        self.past_unit = past_unit
        self.future_unit = future_unit

    # forward function
    def forward(self, input):
        outputs = []
        rrs = []
        sigmas = []
        device = input.device
        h_t = torch.zeros(input.size(0), self.hidden_size, dtype=torch.float, device=device)
        c_t = torch.zeros(input.size(0), self.hidden_size, dtype=torch.float, device=device)
        
        
        for i in range(input.size(1)):
            h_t, c_t = self.lstm(input[:, i, :], (h_t, c_t))
            # h_t = F.dropout(h_t, p=DROPOUT_RATE)
            output, rr = self.conc_drop(h_t, self.linear)
            output_sigma, rr2 = self.conc_drop(h_t, self.sigma)
            # output = self.linear(F.relu(self.linear2(h_t)))
            outputs.append(output)
            sigmas.append(output_sigma)
            rrs.append(rr + rr2)
            
        outputs = torch.stack(outputs, 1).squeeze(2)
        sigmas = torch.stack(sigmas, 1).squeeze()
        rrs = torch.stack(rrs, 1).squeeze()
        return outputs, sigmas, rrs

        
    
    def forward_test_with_past(self, input, dropout_rate=0, dropout_type=0):
        outputs = []
        output_sigmas = []
        rrs = []
        device = input.device
        h_t = torch.zeros(input.size(0), self.hidden_size, dtype=torch.float, device=device)
        c_t = torch.zeros(input.size(0), self.hidden_size, dtype=torch.float, device=device)
        
        input_local = input[:, 0, :]
        
        for i in range(self.past_unit+1):
            h_t, c_t = self.lstm(input[:, i, :], (h_t, c_t))
            # h_t, c_t = self.lstm(input_local, (h_t, c_t))
            # h_t, c_t = self.lstm(input[:, i, :], (h_t, c_t))
            # h_t = F.dropout(h_t, p=dropout_rate)
            output, rr = self.conc_drop(h_t, self.linear)
            output_sigma, rr2 = self.conc_drop(h_t, self.sigma)
            # output = self.linear(F.relu(self.linear2(h_t)))
            input_local = output
            # outputs += [output]
        
        outputs.append(input_local)   
        output_sigmas.append(output_sigma)
        rrs.append(rr+rr2)
        for i in range(self.future_unit-1):
            h_t, c_t = self.lstm(input_local,(h_t, c_t))
            # h_t, c_t = self.lstm(input_local, (h_t, c_t))
            # h_t = F.dropout(h_t, p=dropout_rate)
            output, rr = self.conc_drop(h_t, self.linear)
            
            output_sigma, rr2 = self.conc_drop(h_t, self.sigma)
            # output = self.linear(F.relu(self.linear2(h_t)))
            input_local = output
            outputs.append(output)
            output_sigmas.append(output_sigma)
            rrs.append(rr + rr2)
            # print(outputs)
        
        # print(outputs)
        outputs = torch.stack(outputs, 1).squeeze(2)
        output_sigmas = torch.stack(output_sigmas, 1).squeeze()
        rrs = torch.stack(rrs, 1).squeeze()
        #print('output: ', output.shape, output)
        #print('sigma: ', output_sigmas.shape, output_sigmas)
        #print('target: ', target.shape, target)
        #print('rrs: ', rrs.shape, rrs)
        #print('outputs from test function: ', outputs.shape, outputs)
        return outputs, output_sigmas, rrs