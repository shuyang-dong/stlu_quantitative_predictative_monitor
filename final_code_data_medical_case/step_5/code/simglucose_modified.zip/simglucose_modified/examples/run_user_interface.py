from simglucose.simulation.user_interface import simulate
simulate()
